﻿#include <iostream>
#include "Commands.h"
using namespace std;
int main()
{
    Commands com;
    com.run();
    return 0;
}

